#' @param signal string specifying the name of the signal as used in
#'     `parquet` input data filenames. One indicator can be associated
#'     with multiple signals.
