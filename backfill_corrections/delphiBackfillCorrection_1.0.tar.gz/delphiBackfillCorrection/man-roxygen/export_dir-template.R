#' @param export_dir path to directory to save output to
