#' @param df Data Frame of aggregated counts within a single location
#'    reported for each reference date and issue date.
