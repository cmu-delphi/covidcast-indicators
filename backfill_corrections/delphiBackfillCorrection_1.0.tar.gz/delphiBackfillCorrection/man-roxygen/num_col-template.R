#' @param num_col name of numerator column in the input dataframe
