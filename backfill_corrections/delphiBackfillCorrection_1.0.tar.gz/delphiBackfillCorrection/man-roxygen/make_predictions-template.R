#' @param make_predictions boolean indicating whether to generate and save
#'     corrections (TRUE) or not. Default is TRUE.
