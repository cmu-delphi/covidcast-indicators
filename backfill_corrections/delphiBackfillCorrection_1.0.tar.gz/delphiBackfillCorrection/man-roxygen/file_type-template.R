#' @param file_type string specifying time period coverage of input files.
#'     Either "daily" or "rollup"
