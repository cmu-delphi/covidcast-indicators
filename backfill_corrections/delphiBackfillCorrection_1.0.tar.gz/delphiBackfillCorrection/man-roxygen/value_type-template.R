#' @param value_type string describing signal type. Either "count" or "fraction".
