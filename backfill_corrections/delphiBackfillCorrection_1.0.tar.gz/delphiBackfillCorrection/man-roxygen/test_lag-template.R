#' @param test_lag integer number of days ago to predict for
