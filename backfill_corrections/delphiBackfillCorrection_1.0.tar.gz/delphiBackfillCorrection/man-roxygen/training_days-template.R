#' @param training_days integer number of days to use for training
