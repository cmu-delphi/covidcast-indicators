#' @param value_col string specifying name of value (counts) field within
#'     the input dataframe.
