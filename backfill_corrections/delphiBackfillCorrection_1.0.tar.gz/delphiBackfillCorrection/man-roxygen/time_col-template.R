#' @param time_col string specifying name of column used for the
#'     date, can be either reference date or issue date
