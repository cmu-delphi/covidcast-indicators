#' @param refd_col string specifying name of reference date field within
#'     the input dataframe.
