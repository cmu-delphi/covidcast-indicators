#' @param ref_lag max lag to use for training
