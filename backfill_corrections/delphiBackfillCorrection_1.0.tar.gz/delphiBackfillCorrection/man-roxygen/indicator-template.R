#' @param indicator string specifying the name of the indicator as used in
#'     `parquet` input data filenames. One indicator can be associated
#'     with multiple signals.
