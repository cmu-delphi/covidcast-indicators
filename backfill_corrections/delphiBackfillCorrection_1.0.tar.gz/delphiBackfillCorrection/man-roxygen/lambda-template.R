#' @param lambda the level of lasso penalty
