#' @param testing_window the testing window used for saving the runtime. Could
#'     set it to be 1 if time allows
