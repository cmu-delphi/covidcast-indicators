#' @param covariates character vector of column names serving as the covariates for the model
