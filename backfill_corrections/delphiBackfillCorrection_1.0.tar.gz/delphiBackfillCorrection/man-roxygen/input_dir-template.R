#' @param input_dir path to the directory containing input data
