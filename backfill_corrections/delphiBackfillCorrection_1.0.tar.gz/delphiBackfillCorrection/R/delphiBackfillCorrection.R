# Load `tribble` for defining global variables
#' @importFrom tibble tribble
NULL
