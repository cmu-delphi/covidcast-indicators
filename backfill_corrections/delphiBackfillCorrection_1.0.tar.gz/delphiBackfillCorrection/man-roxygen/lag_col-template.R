#' @param lag_col string specifying name of lag field within
#'     the input dataframe.
