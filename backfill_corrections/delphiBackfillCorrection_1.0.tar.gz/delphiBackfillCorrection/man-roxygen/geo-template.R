#' @param geo string specifying the name of the geo region (e.g. FIPS
#'     code for counties)
