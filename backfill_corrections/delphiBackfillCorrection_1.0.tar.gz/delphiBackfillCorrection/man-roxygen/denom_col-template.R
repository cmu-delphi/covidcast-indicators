#' @param denom_col name of denominator column in the input dataframe
