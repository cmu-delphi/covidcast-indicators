library(testthat)
library(delphiBackfillCorrection)

test_check("delphiBackfillCorrection", stop_on_warning = FALSE)
