#' @param taus numeric vector of quantiles to be predicted. Values
#'     must be between 0 and 1.
