#' @param train_models boolean indicating whether to train models (TRUE). If
#'     FALSE previously trained models (stored locally) will be used instead.
#'     Default is TRUE.
