#' @param geo_level string describing geo coverage of input data. Either "state"
#'     or "county".
